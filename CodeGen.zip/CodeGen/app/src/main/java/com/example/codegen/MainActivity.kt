package com.example.codegen

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val txtCode:TextView = findViewById(R.id.code);
        val etCode:EditText = findViewById(R.id.input);
        val btnSend:TextView = findViewById(R.id.send);
    }
}